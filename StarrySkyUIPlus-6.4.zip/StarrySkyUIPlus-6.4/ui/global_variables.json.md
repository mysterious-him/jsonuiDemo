# global_variables.json 参数说明
# 全局变量定义，在所有 UI JSON 中通过 $变量名 引用

{

    # ========== 表单尺寸 ==========

    "$sky_longform_size": [ "90%", "90%" ],
    # 长表单尺寸 [宽, 高]，占屏幕 90%

    "$sky_panel_indent_size": ["75%", "39%x"],
    # 内容区域大小，"39%x" 表示高度为宽度的 39%

    # ========== 消息表单 ==========

    "$sky_message_form_size": [245, 187.5],
    # 消息表单弹窗尺寸 [宽, 高]

    "$sky_message_form_body_size": ["100%", 152.5],
    # 消息表单背景图尺寸

    "$sky_message_form_two_buttons_panel_size": [ "100%-5px", 32.5 ],
    # 双按钮面板尺寸

    "$sky_message_form_title_text_color": [0.608, 0.365, 0.082],
    # 标题颜色 [R,G,B]，对应 #9B5D15（棕色）

    "$sky_message_form_text_color": [0.608, 0.365, 0.082],
    # 正文颜色 [R,G,B]

    # ========== 版权信息 ==========

    "$sky_copyright_info": "UI\n"
    # 表单右下角版权文字
}
