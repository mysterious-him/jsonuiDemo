# ui_defs.json 参数说明

{
    "ui_defs": [
        # ui_defs: 数组，列出所有要加载的 UI JSON 文件路径

        "ui/menu/index.json",
        # 路由分发器（根据标题前缀决定显示哪个表单）

        "ui/menu/main.json",
        # 主菜单网格布局

        "ui/menu/text.json",
        # 自定义文本表单

        "ui/menu/sky_common.json"
        # 公共组件库（标题栏、关闭按钮、版权信息）
    ]
}
