# index.json 参数说明
# 路由分发器：根据表单标题前缀决定显示哪个 UI 面板（核心机制）

{
    "namespace": "sky_form",

    "long_form_replacement": {
    # 长表单替换器
        "type": "panel",
        "size": ["100%", "100%"],
        "controls": [{
            "sky_main@form_type": {
                "$min": "/D ",
                # 前缀匹配起始值

                "$max": "/D 􀐏",
                # 前缀匹配结束值

                "$content": "form_main.main"
                # 匹配后显示主菜单网格
            }
        }]
    },

    "custom_form_replacement": {
    # 自定义表单替换器
        "type": "panel",
        "size": ["100%", "100%"],
        "controls": [{
            "text@form_type": {
                "$min": "/TEXT ",
                "$max": "/TEXT 􀐏",
                "$content": "form_text.main"
                # /TEXT 前缀 → 文本表单
            }
        }]
    },

    "form_type": {
    # 通用路由控件模板
        "type": "panel",
        "anchor_from": "center",
        "anchor_to": "center",
        "controls": [{ "content@$content": {} }],
        # 显示 $content 指定的面板

        "visible": false,
        # 默认不可见

        "bindings": [
            { "binding_name": "#title_text" },
            # 绑定表单标题

            {
                "binding_type": "view",
                "source_property_name": "(#title_text = $min) or (#title_text > $min and #title_text < $max)",
                # 标题在前缀范围内时显示

                "target_property_name": "#visible"
            },
            {
                "binding_type": "view",
                "source_property_name": "(#title_text - $min)",
                # 去掉前缀后的标题

                "target_property_name": "#title"
            }
        ]
    }
}
