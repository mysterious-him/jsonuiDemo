# sky_common.json 参数说明
# 公共可复用组件：标题栏、关闭按钮、版权信息

{
    "namespace": "sky_common",

    "header": {
    # 顶部标题栏
        "anchor_from": "top_middle",
        "anchor_to": "top_middle",
        "$close_button_to_button_id": "button.exit_student",
        "type": "image",
        "layer": 1,
        "size": ["100%", 27],
        # 全宽，高 27 像素

        "texture": "textures/menu/bg",
        # 背景贴图

        "controls": [
            { "close@close": {} },
            # 关闭按钮

            { "title@title": {} }
            # 标题文字
        ]
    },

    "close@common.close_button": {
    # 关闭按钮
        "type": "button",
        "anchor_from": "right_middle",
        "anchor_to": "right_middle",
        "size": [30, 30],
        # 30x30 像素

        "offset": [6, -5],
        # 向右 6 向上 5 像素

        "$close_button_to_button_id": "button.menu_exit",
        # 按下后触发 button.menu_exit

        "controls": [
            { "default@common.close_button_panel": { "$close_button_texture": "textures/menu/exit" } },
            # 默认状态

            { "hover@common.close_button_panel": { "$close_button_texture": "textures/menu/exit_hover" } },
            # 悬停状态

            { "pressed@common.close_button_panel": { "$close_button_texture": "textures/menu/exit_pressed" } }
            # 按下状态
        ]
    },

    "title": {
    # 标题文字
        "type": "label",
        "text": "$form_title",
        # 从 $form_title 变量获取文字

        "font_size": "large",
        "font_scale_factor": 0.8,
        "color": [1, 1, 1],
        # 白色

        "anchor_from": "left_middle",
        "anchor_to": "left_middle",
        "text_alignment": "left",
        "offset": [1, 2],
        "size": ["100%", "100%"]
    },

    "copyright_info": {
    # 版权信息（右下角）
        "type": "panel",
        "size": ["100%cm", "100%cm"],
        "offset": [-6, -3],
        "anchor_from": "bottom_right",
        "anchor_to": "bottom_right",
        "controls": [{
            "item_text_label": {
                "type": "label",
                "max_size": [200, "default"],
                "font_scale_factor": 0.6,
                "text_alignment": "right",
                "layer": 31,
                "color": [1, 1, 1],
                "text": "StarrySkyUIPlus",
                # 硬编码版权文字

                "alpha": 0.5
                # 半透明
            }
        }]
    }
}
