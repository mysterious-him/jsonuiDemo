# main.json 参数说明
# 主菜单网格布局：2+3+3 按钮排列

{
    "namespace": "form_main",

    "main": {
    # 主面板入口
        "type": "panel",
        "size": ["100%","100%"],
        "controls": [{"items_m@form_main.items": {}}]
    },

    "items": {
    # 按钮容器
        "type": "panel",
        "orientation": "vertical",
        "size": ["85%","39%x"],
        # 宽 85%，高为宽的 39%

        "controls": [{"1@form_main.items_1": {}}]
    },

    "items_1": {
    # 按钮网格（3 行）
        "type": "stack_panel",
        "orientation": "vertical",
        "size": ["50%","100%"],
        "offset": [0, "-8%"],
        # 向上偏移 8%

        "controls": [
        {"header@sky_common.header": { "$form_title":"主菜单" }},
        # 标题栏

        {"line1":{
        # 第 1 行：2 个按钮（各 50%）
            "type":"stack_panel",
            "orientation":"horizontal",
            "size":["100%","33.33%"],
            "collection_name": "form_buttons",
            "controls":[
            { "0@button2": { "$index": 0, "$hover_texture":"textures/menu/01", "$pressed_texture":"textures/menu/01_pressed" } },
            # 按钮 0
            { "1@button2": { "$index": 1, "$hover_texture":"textures/menu/02", "$pressed_texture":"textures/menu/02_pressed" } }
            # 按钮 1
            ]
        }},
        {"line2":{
        # 第 2 行：3 个按钮（各 33.33%）
            "type":"stack_panel",
            "size":["100%","33.33%"],
            "orientation":"horizontal",
            "collection_name": "form_buttons",
            "controls":[
            { "2@button1": { "$index": 2, "$hover_texture":"textures/menu/03", "$pressed_texture":"textures/menu/03_pressed" } },
            # 按钮 2
            { "3@button1": { "$index": 3, "$hover_texture":"textures/menu/04", "$pressed_texture":"textures/menu/04_pressed" } },
            # 按钮 3
            { "4@button1": { "$index": 4, "$hover_texture":"textures/menu/05", "$pressed_texture":"textures/menu/05_pressed" } }
            # 按钮 4
            ]
        }},
        {"line3":{
        # 第 3 行：3 个按钮（各 33.33%）
            "type":"stack_panel",
            "size":["100%","33.33%"],
            "orientation":"horizontal",
            "collection_name": "form_buttons",
            "controls":[
            { "5@button1": { "$index": 5, "$hover_texture":"textures/menu/06", "$pressed_texture":"textures/menu/06_pressed" } },
            # 按钮 5
            { "6@button1": { "$index": 6, "$hover_texture":"textures/menu/07", "$pressed_texture":"textures/menu/07_pressed" } },
            # 按钮 6
            { "7@button1": { "$index": 7, "$hover_texture":"textures/menu/08", "$pressed_texture":"textures/menu/08_pressed" } }
            # 按钮 7
            ]
        }}
        ]
    },

    "button1@button":{ "size": ["33.33%", "100%"] },
    # 标准 1/3 宽度

    "button2@button":{ "size": ["50%", "100%"] },
    # 第 1 行按钮：50% 宽度

    "button@common.button": {
    # 通用按钮模板
        "collection_index": "$index",
        "$pressed_button_name": "button.form_button_click",
        "locked_control": "locked",
        "controls": [
            { "default@button_content": { "texture": "$hover_texture" } },
            # 默认状态

            { "hover@button_content": { "texture": "$pressed_texture" } },
            # 悬停状态

            { "pressed@button_content": { "texture": "$pressed_texture" } },
            # 按下状态

            { "locked@button_content": { "texture": "$pressed_texture" } }
            # 锁定状态
        ],
        "bindings": [
            { "binding_type": "collection_details", "binding_collection_name": "form_buttons" },
            {
                "binding_name": "#form_button_text",
                # 从服务器获取按钮文字

                "binding_name_override": "#text",
                "binding_type": "collection",
                "binding_collection_name": "form_buttons"
            },
            {
                "binding_type": "view",
                "source_property_name": "(#text < '$' or #text > '$􀐏' )",
                "target_property_name": "#enabled"
            },
            { "binding_type": "view",
              "source_property_name": "(not (#text = ''))",
              "target_property_name": "#visible"
            }
        ]
    },

    "button_content": { "type": "image", "size": ["100%","100%"], "alpha": 0.8 }
    # 按钮内容：图片，80% 不透明度
}
