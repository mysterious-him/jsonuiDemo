# text.json 参数说明
# 自定义文本表单（/TEXT 前缀触发）

{
    "namespace": "form_text",
    "main": {
        "type": "panel",
        "size": ["100%", "100%"],
        "controls": [
            { "@sky_common.header": { "$binding": "#title" } },
            # 标题栏绑定到去掉前缀的标题

            { "@server_form.custom_form_panel": {} }
            # 使用原版自定义表面板
        ]
    }
}
