# server_form.json 参数说明
# 修改原版服务器表单，注入 StarrySkyUI 自定义渲染

{
    "namespace": "server_form",

    "third_party_server_screen@common.base_screen": {
    # 第三方服务器屏幕
        "$screen_animations|default": [
            "@common.screen_exit_animation_push_fade",
            "@common.screen_exit_animation_pop_fade",
            "@common.screen_entrance_animation_push_fade",
            "@common.screen_entrance_animation_pop_fade"
            # 只保留淡入淡出动画
        ],
        "$screen_content": "server_form.main_screen_content",
        "gamepad_cursor": true
    },

    "main_screen_content": {
    # 主屏幕内容
        "size": ["100%", "100%"],
        "modifications": [{
            "array_name": "controls",
            "operation": "insert_front",
            "value": [
                { "server_form_factory": {
                    "type": "factory",
                    "control_ids": {
                        "long_form": "long_form_replacement@sky_form.long_form_replacement",
                        # 长表单 → StarrySkyUI 路由

                        "custom_form": "custom_form_replacement@sky_form.custom_form_replacement"
                        # 自定义表单 → StarrySkyUI 路由
                    }
                }},
                { "background@sky_common.background": {} },
                # 注入背景

                { "copyright@sky_common.copyright_info": {} }
                # 注入版权信息
            ]
        }]
    },

    "long_form": { "modifications": [{ "array_name": "bindings", "operation": "insert_front", "value": [{ "binding_type": "view", "source_control_name": "inside_header_panel", "source_property_name": "#sky_visible", "target_property_name": "#visible" }] }] },

    "long_form_panel": { "modifications": [{ "array_name": "bindings", "operation": "insert_front", "value": [{ "binding_type": "view", "source_property_name": "(#title_text < '/' or #title_text > '/􀐏')", "target_property_name": "#sky_visible" }] }] },

    "custom_form": { "modifications": [{ "array_name": "bindings", "operation": "insert_front", "value": [{ "binding_type": "view", "source_control_name": "inside_header_panel", "source_property_name": "#sky_visible", "target_property_name": "#visible" }] }] },

    "custom_form_panel": { "modifications": [{ "array_name": "bindings", "operation": "insert_front", "value": [{ "binding_type": "view", "source_property_name": "(#title_text < '/' or #title_text > '/􀐏')", "target_property_name": "#sky_visible" }] }] }
}
